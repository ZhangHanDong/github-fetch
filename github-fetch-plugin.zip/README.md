# github-fetch

A Rust library for fetching GitHub issues, pull requests, discussions, reviews, and diff information via the GitHub API.

## Features

- Fetch issues and pull requests with flexible filtering
- Fetch PR reviews (approved, changes requested, etc.)
- Fetch PR review comments (inline comments on diff)
- Fetch PR file changes with diff/patch content
- Fetch GitHub Discussions via GraphQL API
- Rate limiting and retry support
- Builder pattern for configuration

## Installation

Add to your `Cargo.toml`:

```toml
[dependencies]
github-fetch = { path = "." }
tokio = { version = "1", features = ["full"] }
anyhow = "1.0"
```

## Authentication

Set your GitHub token as an environment variable:

```bash
export GITHUB_TOKEN=ghp_your_token_here
```

## Usage

### Basic Usage

```rust
use github_fetch::{GitHubFetcher, Repository};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // Create a fetcher (reads GITHUB_TOKEN from env)
    let fetcher = GitHubFetcher::new(None)?;

    // Or provide token directly
    let fetcher = GitHubFetcher::new(Some("ghp_your_token".to_string()))?;

    let repo = Repository::new("tokio-rs", "tokio");

    // Test connection
    fetcher.test_connection().await?;

    // Check rate limit
    let rate_limit = fetcher.get_rate_limit().await?;
    println!("{}", rate_limit);

    Ok(())
}
```

### Using the Builder Pattern

```rust
use github_fetch::GitHubFetcherBuilder;

let fetcher = GitHubFetcherBuilder::new()
    .token("ghp_your_token")           // Set token directly
    .user_agent("my-app/1.0.0")        // Custom user agent
    .rate_limit(30)                     // Requests per minute
    .max_retries(5)                     // Max retry attempts
    .timeout(60)                        // Timeout in seconds
    .build()?;
```

### Fetching Issues

```rust
use github_fetch::{GitHubFetcher, Repository, IssueFilters, IssueState};

let fetcher = GitHubFetcher::new(None)?;
let repo = Repository::new("tokio-rs", "tokio");

// Fetch with default filters
let issues = fetcher.fetch_issues(&repo, &IssueFilters::default()).await?;

// Fetch with custom filters
let filters = IssueFilters {
    state: IssueState::Closed,
    include_labels: vec!["bug".to_string()],
    exclude_labels: vec!["duplicate".to_string()],
    min_comments: Some(3),
    min_body_length: Some(100),
    code_blocks_only: true,
    ..Default::default()
};

let result = fetcher.fetch_issues_with_limit(&repo, &filters, 10).await?;
println!("Found {} issues", result.issues.len());

for issue in &result.issues {
    println!("#{}: {} ({})", issue.number, issue.title, issue.state);
}
```

### Fetching a Single Issue or PR

```rust
// Fetch a specific issue
let issue = fetcher.fetch_issue(&repo, 6800).await?;
println!("Title: {}", issue.title);
println!("State: {}", issue.state);
println!("Author: {}", issue.user.login);

// Fetch a specific PR
let pr = fetcher.fetch_pr(&repo, 1234).await?;
if let Some(merged_at) = pr.merged_at {
    println!("Merged at: {}", merged_at);
}
```

### Fetching Issue/PR Comments

```rust
let comments = fetcher.fetch_comments(&repo, 6800).await?;
println!("Found {} comments", comments.len());

for comment in &comments {
    println!("--- {} said ---", comment.user.login);
    println!("{}", comment.body);
}
```

### Fetching PR Reviews

```rust
use github_fetch::{GitHubFetcher, Repository};

let fetcher = GitHubFetcher::new(None)?;
let repo = Repository::new("tokio-rs", "axum");

// Fetch all reviews for a PR
let reviews = fetcher.fetch_pr_reviews(&repo, 2865).await?;

for review in &reviews {
    println!("Review by {}: {}", review.user.login, review.state);
    // state: APPROVED, CHANGES_REQUESTED, COMMENTED, DISMISSED, PENDING

    if let Some(body) = &review.body {
        println!("Comment: {}", body);
    }

    if let Some(submitted_at) = review.submitted_at {
        println!("Submitted at: {}", submitted_at);
    }
}
```

### Fetching PR Review Comments (Inline Diff Comments)

```rust
// Fetch inline comments on the diff
let review_comments = fetcher.fetch_pr_review_comments(&repo, 2865).await?;

for comment in &review_comments {
    println!("File: {}", comment.path);

    if let Some(line) = comment.line {
        println!("Line: {}", line);
    }

    println!("Comment: {}", comment.body);
    println!("Diff context:\n{}", comment.diff_hunk);

    // Check if this is a reply to another comment
    if let Some(reply_to) = comment.in_reply_to_id {
        println!("In reply to comment: {}", reply_to);
    }
}
```

### Fetching PR File Changes (Diff)

```rust
let files = fetcher.fetch_pr_files(&repo, 2865).await?;

for file in &files {
    println!("File: {}", file.filename);
    println!("Status: {}", file.status);  // Added, Modified, Removed, Renamed
    println!("Changes: +{} -{}", file.additions, file.deletions);

    // Get the actual diff/patch content
    if let Some(patch) = &file.patch {
        println!("Diff:\n{}", patch);
    }
}
```

### Fetching Discussions

```rust
let repo = Repository::new("actix", "actix-web");

// Fetch by number
let discussion = fetcher.fetch_discussion(&repo, 3766).await?;
println!("Title: {}", discussion.title);
println!("Author: {}", discussion.author.login);
println!("Body: {}", discussion.body);

for comment in &discussion.comments {
    println!("--- {} commented ---", comment.author.login);
    println!("{}", comment.body);
}

// Fetch by URL
let discussion = fetcher.fetch_discussion_by_url(
    "https://github.com/actix/actix-web/discussions/3766"
).await?;
```

### Repository Creation Methods

```rust
use github_fetch::Repository;

// From owner and name
let repo = Repository::new("owner", "repo");

// From full name
let repo = Repository::from_full_name("owner/repo")?;

// From URL
let repo = Repository::from_url("https://github.com/owner/repo")?;
```

### Filtering Utilities

```rust
use github_fetch::{has_code_blocks, has_rust_error_codes, extract_error_codes};

let text = "Error E0382: use of moved value";

// Check for Rust error codes
if has_rust_error_codes(text) {
    let codes = extract_error_codes(text);
    println!("Found error codes: {:?}", codes);  // ["E0382"]
}

// Check for code blocks
let markdown = "```rust\nfn main() {}\n```";
assert!(has_code_blocks(markdown));
```

### Rust Error-Focused Filtering

```rust
// Pre-configured filter for Rust compiler error issues
let filters = IssueFilters::rust_error_focused();

// This sets:
// - include_labels: ["E-help-wanted", "A-diagnostics", "A-borrowck", "E-easy", "E-medium"]
// - rust_errors_only: true
// - code_blocks_only: true
// - min_body_length: 100
```

## Data Structures

### GitHubIssue / PR

```rust
pub struct GitHubIssue {
    pub id: u64,
    pub number: u64,
    pub title: String,
    pub body: Option<String>,
    pub state: String,
    pub labels: Vec<GitHubLabel>,
    pub user: GitHubUser,
    pub assignees: Vec<GitHubUser>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub closed_at: Option<DateTime<Utc>>,
    pub merged_at: Option<DateTime<Utc>>,  // For PRs
    pub html_url: String,
    pub is_pull_request: bool,
    pub comments: u32,
}
```

### PrReview

```rust
pub struct PrReview {
    pub id: u64,
    pub user: GitHubUser,
    pub body: Option<String>,
    pub state: String,  // APPROVED, CHANGES_REQUESTED, COMMENTED, DISMISSED, PENDING
    pub submitted_at: Option<DateTime<Utc>>,
    pub html_url: String,
    pub commit_id: Option<String>,
}
```

### PrReviewComment

```rust
pub struct PrReviewComment {
    pub id: u64,
    pub review_id: Option<u64>,
    pub user: GitHubUser,
    pub body: String,
    pub path: String,              // File path
    pub line: Option<u32>,         // Line number in diff
    pub original_line: Option<u32>,
    pub diff_hunk: String,         // Diff context
    pub side: Option<String>,      // LEFT or RIGHT
    pub commit_id: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub html_url: String,
    pub position: Option<u32>,
    pub in_reply_to_id: Option<u64>,
}
```

### PrFile

```rust
pub struct PrFile {
    pub filename: String,
    pub status: String,       // Added, Modified, Removed, Renamed
    pub additions: u32,
    pub deletions: u32,
    pub changes: u32,
    pub patch: Option<String>, // The actual diff content
}
```

## Examples

Run the examples with:

```bash
export GITHUB_TOKEN=ghp_your_token

# Fetch a Tokio issue
cargo run --example fetch_tokio_issue

# Fetch an Axum PR with files
cargo run --example fetch_axum_pr

# Fetch with custom filters
cargo run --example fetch_with_filters

# Fetch a discussion
cargo run --example fetch_actix_discussion

# Advanced usage with builder pattern
cargo run --example advanced_usage
```

## Error Handling

```rust
use github_fetch::{GitHubFetcher, GitHubFetchError, Repository};

let fetcher = GitHubFetcher::new(None)?;
let repo = Repository::new("owner", "repo");

match fetcher.fetch_issue(&repo, 999999).await {
    Ok(issue) => println!("Found: {}", issue.title),
    Err(GitHubFetchError::NotFound(msg)) => println!("Not found: {}", msg),
    Err(GitHubFetchError::AuthError(msg)) => println!("Auth error: {}", msg),
    Err(GitHubFetchError::RateLimitExceeded) => println!("Rate limited!"),
    Err(e) => println!("Other error: {}", e),
}
```

## Claude Code Skill

This project includes a Claude Code Skill for PR review and fixing.

### Install as Plugin

```bash
claude plugins add https://github.com/you/github-fetch
```

### Or Copy Skill Manually

```bash
# Global (available in all projects)
cp -r skills/pr-review ~/.claude/skills/

# Project-level (available in one project)
cp -r skills/pr-review .claude/skills/
```

### Usage

After installation, just ask Claude naturally:

```
Review PR https://github.com/owner/repo/pull/123
```

```
帮我分析这个 PR 的 review 意见并修复问题
```

The skill will:
1. Fetch PR details, diffs, and review comments
2. Present a summary of issues
3. Fix code based on review feedback
4. Re-review the changes

### Requirements

- `GITHUB_TOKEN` environment variable must be set
- This crate must be available in the project

## License

MIT OR Apache-2.0
